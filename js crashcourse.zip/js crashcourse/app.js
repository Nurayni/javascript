// var name = 'MOU'
// console.log(name);
// var names = [];
// names[0] = 'mou';
// names[1] = 'fahim';
// names[2] = 'popy';
// names[3] = 'liton';


// console.log(names);

// for (var i = 0; i < names.length; i++)
//     console.log('Hello,' + names[i].toUpperCase());

var names = ['Mou', 'Fahim', 'Popy', 'Liton'];
console.log(names.length);
console.log(names[1]);
console.log(names[names.length - 1]);
console.log(names.indexOf('Mou'));
console.log(names[names.length] = 'Someone');


var sorted = names.sort();
console.log(sorted);

names.splice(1, 1);
console.log(names);